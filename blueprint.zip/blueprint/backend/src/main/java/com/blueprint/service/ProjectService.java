package com.blueprint.service;

import com.blueprint.dto.ProjectDTO;
import com.blueprint.entity.Project;
import com.blueprint.exception.ResourceNotFoundException;
import com.blueprint.repository.ProjectRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class ProjectService {

    private final ProjectRepository projectRepository;

    public List<ProjectDTO> getAllProjects() {
        return projectRepository.findAll().stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public ProjectDTO getProjectById(Long id) {
        Project project = findProjectOrThrow(id);
        return toDTO(project);
    }

    public ProjectDTO createProject(ProjectDTO dto) {
        Project project = new Project();
        project.setName(dto.getName());
        project.setDescription(dto.getDescription());
        Project saved = projectRepository.save(project);
        return toDTO(saved);
    }

    public ProjectDTO updateProject(Long id, ProjectDTO dto) {
        Project project = findProjectOrThrow(id);
        project.setName(dto.getName());
        project.setDescription(dto.getDescription());
        Project saved = projectRepository.save(project);
        return toDTO(saved);
    }

    public void deleteProject(Long id) {
        Project project = findProjectOrThrow(id);
        projectRepository.delete(project);
    }

    private Project findProjectOrThrow(Long id) {
        return projectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Project not found with id: " + id));
    }

    private ProjectDTO toDTO(Project project) {
        return new ProjectDTO(
                project.getId(),
                project.getName(),
                project.getDescription(),
                project.getCreatedAt(),
                project.getUpdatedAt(),
                project.getFloorPlans() == null ? 0 : project.getFloorPlans().size()
        );
    }
}
