package com.blueprint.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FloorPlanDTO {
    private Long id;

    @NotBlank(message = "Floor plan name is required")
    private String name;

    @NotNull
    private Long projectId;

    private Integer canvasWidth;
    private Integer canvasHeight;

    private List<RoomDTO> rooms;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
