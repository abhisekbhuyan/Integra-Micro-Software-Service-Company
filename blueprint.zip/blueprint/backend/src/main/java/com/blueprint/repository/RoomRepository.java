package com.blueprint.repository;

import com.blueprint.entity.Room;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RoomRepository extends JpaRepository<Room, Long> {
    List<Room> findByFloorPlanId(Long floorPlanId);
    void deleteByFloorPlanId(Long floorPlanId);
}
