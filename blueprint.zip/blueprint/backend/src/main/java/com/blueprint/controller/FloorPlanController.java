package com.blueprint.controller;

import com.blueprint.dto.FloorPlanDTO;
import com.blueprint.service.FloorPlanService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class FloorPlanController {

    private final FloorPlanService floorPlanService;

    @GetMapping("/api/projects/{projectId}/floorplans")
    public ResponseEntity<List<FloorPlanDTO>> getFloorPlansForProject(@PathVariable Long projectId) {
        return ResponseEntity.ok(floorPlanService.getFloorPlansForProject(projectId));
    }

    @GetMapping("/api/floorplans/{id}")
    public ResponseEntity<FloorPlanDTO> getFloorPlan(@PathVariable Long id) {
        return ResponseEntity.ok(floorPlanService.getFloorPlanById(id));
    }

    @PostMapping("/api/floorplans")
    public ResponseEntity<FloorPlanDTO> createFloorPlan(@Valid @RequestBody FloorPlanDTO dto) {
        FloorPlanDTO created = floorPlanService.createFloorPlan(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/api/floorplans/{id}")
    public ResponseEntity<FloorPlanDTO> updateFloorPlan(@PathVariable Long id, @Valid @RequestBody FloorPlanDTO dto) {
        return ResponseEntity.ok(floorPlanService.updateFloorPlan(id, dto));
    }

    @DeleteMapping("/api/floorplans/{id}")
    public ResponseEntity<Void> deleteFloorPlan(@PathVariable Long id) {
        floorPlanService.deleteFloorPlan(id);
        return ResponseEntity.noContent().build();
    }
}
