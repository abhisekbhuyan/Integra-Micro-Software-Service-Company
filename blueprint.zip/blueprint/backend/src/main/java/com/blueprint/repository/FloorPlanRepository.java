package com.blueprint.repository;

import com.blueprint.entity.FloorPlan;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FloorPlanRepository extends JpaRepository<FloorPlan, Long> {
    List<FloorPlan> findByProjectId(Long projectId);
}
