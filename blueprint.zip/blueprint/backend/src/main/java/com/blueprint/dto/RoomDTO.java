package com.blueprint.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoomDTO {
    private Long id;

    @NotBlank(message = "Room label is required")
    private String label;

    private String roomType;

    @NotNull
    private Double x;

    @NotNull
    private Double y;

    @NotNull
    private Double width;

    @NotNull
    private Double height;

    private Double rotation;
    private String color;

    @NotNull
    private Long floorPlanId;
}
