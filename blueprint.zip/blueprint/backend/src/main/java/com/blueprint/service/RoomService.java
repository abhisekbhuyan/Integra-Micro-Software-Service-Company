package com.blueprint.service;

import com.blueprint.dto.RoomDTO;
import com.blueprint.entity.FloorPlan;
import com.blueprint.entity.Room;
import com.blueprint.exception.ResourceNotFoundException;
import com.blueprint.repository.FloorPlanRepository;
import com.blueprint.repository.RoomRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class RoomService {

    private final RoomRepository roomRepository;
    private final FloorPlanRepository floorPlanRepository;

    public List<RoomDTO> getRoomsForFloorPlan(Long floorPlanId) {
        return roomRepository.findByFloorPlanId(floorPlanId).stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public RoomDTO createRoom(RoomDTO dto) {
        FloorPlan floorPlan = floorPlanRepository.findById(dto.getFloorPlanId())
                .orElseThrow(() -> new ResourceNotFoundException("Floor plan not found with id: " + dto.getFloorPlanId()));

        Room room = new Room();
        applyDtoToEntity(dto, room);
        room.setFloorPlan(floorPlan);

        Room saved = roomRepository.save(room);
        return toDTO(saved);
    }

    public RoomDTO updateRoom(Long id, RoomDTO dto) {
        Room room = findRoomOrThrow(id);
        applyDtoToEntity(dto, room);
        Room saved = roomRepository.save(room);
        return toDTO(saved);
    }

    public void deleteRoom(Long id) {
        Room room = findRoomOrThrow(id);
        roomRepository.delete(room);
    }

    private void applyDtoToEntity(RoomDTO dto, Room room) {
        room.setLabel(dto.getLabel());
        room.setRoomType(dto.getRoomType() != null ? dto.getRoomType() : "GENERIC");
        room.setX(dto.getX());
        room.setY(dto.getY());
        room.setWidth(dto.getWidth());
        room.setHeight(dto.getHeight());
        room.setRotation(dto.getRotation() != null ? dto.getRotation() : 0.0);
        room.setColor(dto.getColor() != null ? dto.getColor() : "#93c5fd");
    }

    private Room findRoomOrThrow(Long id) {
        return roomRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id: " + id));
    }

    private RoomDTO toDTO(Room room) {
        return new RoomDTO(
                room.getId(),
                room.getLabel(),
                room.getRoomType(),
                room.getX(),
                room.getY(),
                room.getWidth(),
                room.getHeight(),
                room.getRotation(),
                room.getColor(),
                room.getFloorPlan().getId()
        );
    }
}
