package com.blueprint.service;

import com.blueprint.dto.FloorPlanDTO;
import com.blueprint.dto.RoomDTO;
import com.blueprint.entity.FloorPlan;
import com.blueprint.entity.Project;
import com.blueprint.entity.Room;
import com.blueprint.exception.ResourceNotFoundException;
import com.blueprint.repository.FloorPlanRepository;
import com.blueprint.repository.ProjectRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class FloorPlanService {

    private final FloorPlanRepository floorPlanRepository;
    private final ProjectRepository projectRepository;

    public List<FloorPlanDTO> getFloorPlansForProject(Long projectId) {
        return floorPlanRepository.findByProjectId(projectId).stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public FloorPlanDTO getFloorPlanById(Long id) {
        return toDTO(findFloorPlanOrThrow(id));
    }

    public FloorPlanDTO createFloorPlan(FloorPlanDTO dto) {
        Project project = projectRepository.findById(dto.getProjectId())
                .orElseThrow(() -> new ResourceNotFoundException("Project not found with id: " + dto.getProjectId()));

        FloorPlan floorPlan = new FloorPlan();
        floorPlan.setName(dto.getName());
        floorPlan.setProject(project);
        floorPlan.setCanvasWidth(dto.getCanvasWidth() != null ? dto.getCanvasWidth() : 900);
        floorPlan.setCanvasHeight(dto.getCanvasHeight() != null ? dto.getCanvasHeight() : 600);

        FloorPlan saved = floorPlanRepository.save(floorPlan);
        return toDTO(saved);
    }

    public FloorPlanDTO updateFloorPlan(Long id, FloorPlanDTO dto) {
        FloorPlan floorPlan = findFloorPlanOrThrow(id);
        floorPlan.setName(dto.getName());
        if (dto.getCanvasWidth() != null) floorPlan.setCanvasWidth(dto.getCanvasWidth());
        if (dto.getCanvasHeight() != null) floorPlan.setCanvasHeight(dto.getCanvasHeight());
        FloorPlan saved = floorPlanRepository.save(floorPlan);
        return toDTO(saved);
    }

    public void deleteFloorPlan(Long id) {
        FloorPlan floorPlan = findFloorPlanOrThrow(id);
        floorPlanRepository.delete(floorPlan);
    }

    private FloorPlan findFloorPlanOrThrow(Long id) {
        return floorPlanRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Floor plan not found with id: " + id));
    }

    private FloorPlanDTO toDTO(FloorPlan floorPlan) {
        List<RoomDTO> rooms = floorPlan.getRooms() == null ? Collections.emptyList() :
                floorPlan.getRooms().stream().map(this::roomToDTO).collect(Collectors.toList());

        return new FloorPlanDTO(
                floorPlan.getId(),
                floorPlan.getName(),
                floorPlan.getProject().getId(),
                floorPlan.getCanvasWidth(),
                floorPlan.getCanvasHeight(),
                rooms,
                floorPlan.getCreatedAt(),
                floorPlan.getUpdatedAt()
        );
    }

    private RoomDTO roomToDTO(Room room) {
        return new RoomDTO(
                room.getId(),
                room.getLabel(),
                room.getRoomType(),
                room.getX(),
                room.getY(),
                room.getWidth(),
                room.getHeight(),
                room.getRotation(),
                room.getColor(),
                room.getFloorPlan().getId()
        );
    }
}
