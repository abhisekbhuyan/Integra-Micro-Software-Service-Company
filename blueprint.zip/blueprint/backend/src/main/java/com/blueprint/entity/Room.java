package com.blueprint.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "rooms", indexes = {
        @Index(name = "idx_room_floorplan", columnList = "floor_plan_id")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false, length = 100)
    private String label;

    @Column(nullable = false)
    private String roomType = "GENERIC"; // e.g. BEDROOM, KITCHEN, BATHROOM, LIVING_ROOM, HALLWAY

    // position + size on the canvas, in design units
    @Column(nullable = false)
    private Double x;

    @Column(nullable = false)
    private Double y;

    @Column(nullable = false)
    private Double width;

    @Column(nullable = false)
    private Double height;

    // rotation in degrees, optional
    @Column(nullable = false)
    private Double rotation = 0.0;

    // hex color for rendering
    @Column(length = 7)
    private String color = "#93c5fd";

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "floor_plan_id", nullable = false)
    @JsonIgnore
    private FloorPlan floorPlan;
}
