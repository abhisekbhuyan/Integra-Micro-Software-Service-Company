# Blueprint — Floor Plan Design Tool

A full-stack app for sketching architectural floor plans: create a **Project**, add one or more **Floor Plans** to it, then draw, move, resize, and label **Rooms** on an interactive canvas.

**Stack:** React.js (frontend) · Java Spring Boot (backend) · MySQL (persistence) · Postman (API testing)

## How it's structured

```
blueprint/
├── backend/     Spring Boot REST API
│   └── src/main/java/com/blueprint/
│       ├── entity/       Project, FloorPlan, Room (JPA entities)
│       ├── dto/          Request/response payloads
│       ├── repository/   Spring Data JPA repositories
│       ├── service/      Business logic
│       ├── controller/   REST endpoints
│       ├── exception/    Centralized error handling
│       └── config/       CORS configuration
├── frontend/    React single-page app
│   └── src/
│       ├── api/          fetch-based API client
│       └── pages/        ProjectList, ProjectDetail, FloorPlanEditor (SVG canvas)
└── postman/     Postman collection covering every endpoint
```

## Data model

- **Project** → has many **Floor Plans**
- **Floor Plan** → belongs to a Project, has many **Rooms**, stores canvas width/height
- **Room** → belongs to a Floor Plan; rectangle defined by `x, y, width, height, rotation`, plus `label`, `roomType`, and `color`

Foreign keys (`project_id`, `floor_plan_id`) are indexed for fast lookups when loading a project's floor plans or a floor plan's rooms.

## Running the backend

1. Create a MySQL database (or let it auto-create — see `application.properties`):
   ```sql
   CREATE DATABASE blueprint_db;
   ```
2. Update `backend/src/main/resources/application.properties` with your MySQL username/password.
3. From `backend/`:
   ```bash
   mvn spring-boot:run
   ```
   The API starts on `http://localhost:8080`. Hibernate auto-creates the `projects`, `floor_plans`, and `rooms` tables on first run (`ddl-auto=update`).

## Running the frontend

From `frontend/`:
```bash
npm install
npm start
```
Opens on `http://localhost:3000` and talks to the API at `http://localhost:8080/api` (override with an `REACT_APP_API_BASE_URL` env var if needed).

## Using the editor

- **Select / Move** mode: click a room to select it, edit its label/type in the side panel, drag it to reposition, or drag the small blue handle at its bottom-right corner to resize it.
- **Draw Room** mode: click and drag anywhere on the canvas to create a new rectangular room — it's saved to the database as soon as you release the mouse.
- Every move, resize, and property edit is persisted via a `PUT /api/rooms/{id}` call; new rooms are created via `POST /api/rooms`.

## Testing the API

Import `postman/Blueprint.postman_collection.json` into Postman. It includes requests for every CRUD endpoint across Projects, Floor Plans, and Rooms, using collection variables (`baseUrl`, `projectId`, `floorPlanId`, `roomId`) so you can run them end-to-end.

## API summary

| Method | Endpoint                              | Purpose                        |
|--------|----------------------------------------|---------------------------------|
| GET    | `/api/projects`                        | List projects                  |
| POST   | `/api/projects`                        | Create project                 |
| GET    | `/api/projects/{id}`                   | Get one project                |
| PUT    | `/api/projects/{id}`                   | Update project                 |
| DELETE | `/api/projects/{id}`                   | Delete project (cascades)      |
| GET    | `/api/projects/{id}/floorplans`        | List floor plans in a project  |
| POST   | `/api/floorplans`                      | Create floor plan              |
| GET    | `/api/floorplans/{id}`                 | Get floor plan + rooms         |
| PUT    | `/api/floorplans/{id}`                 | Update floor plan              |
| DELETE | `/api/floorplans/{id}`                 | Delete floor plan (cascades)   |
| GET    | `/api/floorplans/{id}/rooms`           | List rooms in a floor plan     |
| POST   | `/api/rooms`                           | Create room                    |
| PUT    | `/api/rooms/{id}`                      | Update room (position/size/etc)|
| DELETE | `/api/rooms/{id}`                      | Delete room                    |
