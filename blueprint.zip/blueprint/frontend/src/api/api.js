const BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://localhost:8080/api";

async function request(path, options = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });

  if (!res.ok) {
    let message = `Request failed with status ${res.status}`;
    try {
      const body = await res.json();
      if (body?.messages?.length) message = body.messages.join(", ");
    } catch (_) {
      // response had no JSON body
    }
    throw new Error(message);
  }

  if (res.status === 204) return null;
  return res.json();
}

// ---- Projects ----
export const getProjects = () => request("/projects");
export const getProject = (id) => request(`/projects/${id}`);
export const createProject = (data) =>
  request("/projects", { method: "POST", body: JSON.stringify(data) });
export const updateProject = (id, data) =>
  request(`/projects/${id}`, { method: "PUT", body: JSON.stringify(data) });
export const deleteProject = (id) =>
  request(`/projects/${id}`, { method: "DELETE" });

// ---- Floor plans ----
export const getFloorPlansForProject = (projectId) =>
  request(`/projects/${projectId}/floorplans`);
export const getFloorPlan = (id) => request(`/floorplans/${id}`);
export const createFloorPlan = (data) =>
  request("/floorplans", { method: "POST", body: JSON.stringify(data) });
export const updateFloorPlan = (id, data) =>
  request(`/floorplans/${id}`, { method: "PUT", body: JSON.stringify(data) });
export const deleteFloorPlan = (id) =>
  request(`/floorplans/${id}`, { method: "DELETE" });

// ---- Rooms ----
export const getRoomsForFloorPlan = (floorPlanId) =>
  request(`/floorplans/${floorPlanId}/rooms`);
export const createRoom = (data) =>
  request("/rooms", { method: "POST", body: JSON.stringify(data) });
export const updateRoom = (id, data) =>
  request(`/rooms/${id}`, { method: "PUT", body: JSON.stringify(data) });
export const deleteRoom = (id) => request(`/rooms/${id}`, { method: "DELETE" });
