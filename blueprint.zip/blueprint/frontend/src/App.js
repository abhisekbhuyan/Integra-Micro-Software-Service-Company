import React from "react";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import ProjectList from "./pages/ProjectList";
import ProjectDetail from "./pages/ProjectDetail";
import FloorPlanEditor from "./pages/FloorPlanEditor";
import "./App.css";

export default function App() {
  return (
    <BrowserRouter>
      <div className="app-shell">
        <header className="app-header">
          <Link to="/" className="app-logo">
            📐 Blueprint
          </Link>
          <span className="app-tagline">Floor plan designer</span>
        </header>

        <main className="app-main">
          <Routes>
            <Route path="/" element={<ProjectList />} />
            <Route path="/projects/:projectId" element={<ProjectDetail />} />
            <Route path="/floorplans/:floorPlanId" element={<FloorPlanEditor />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}
