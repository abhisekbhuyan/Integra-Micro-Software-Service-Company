import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getProjects, createProject, deleteProject } from "../api/api";
import "./ProjectList.css";

export default function ProjectList() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");

  const loadProjects = () => {
    setLoading(true);
    getProjects()
      .then(setProjects)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  };

  useEffect(loadProjects, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!name.trim()) return;
    try {
      await createProject({ name, description });
      setName("");
      setDescription("");
      loadProjects();
    } catch (err) {
      setError(err.message);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this project and all its floor plans?")) return;
    try {
      await deleteProject(id);
      loadProjects();
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="project-list">
      <h1>Your Projects</h1>
      {error && <div className="project-list__error">{error}</div>}

      <form className="project-list__form" onSubmit={handleCreate}>
        <input
          type="text"
          placeholder="Project name (e.g. Lakeside Cottage)"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="text"
          placeholder="Description (optional)"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        <button type="submit">+ New Project</button>
      </form>

      {loading ? (
        <p>Loading projects…</p>
      ) : projects.length === 0 ? (
        <p className="project-list__empty">
          No projects yet — create your first one above.
        </p>
      ) : (
        <div className="project-list__grid">
          {projects.map((p) => (
            <div className="project-card" key={p.id}>
              <Link to={`/projects/${p.id}`} className="project-card__title">
                {p.name}
              </Link>
              <p className="project-card__desc">{p.description}</p>
              <div className="project-card__meta">
                {p.floorPlanCount} floor plan{p.floorPlanCount === 1 ? "" : "s"}
              </div>
              <button
                className="project-card__delete"
                onClick={() => handleDelete(p.id)}
              >
                Delete
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
