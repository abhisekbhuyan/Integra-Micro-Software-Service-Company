import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  getProject,
  getFloorPlansForProject,
  createFloorPlan,
  deleteFloorPlan,
} from "../api/api";
import "./ProjectDetail.css";

export default function ProjectDetail() {
  const { projectId } = useParams();
  const [project, setProject] = useState(null);
  const [floorPlans, setFloorPlans] = useState([]);
  const [name, setName] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    Promise.all([getProject(projectId), getFloorPlansForProject(projectId)])
      .then(([proj, plans]) => {
        setProject(proj);
        setFloorPlans(plans);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  };

  useEffect(load, [projectId]);

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!name.trim()) return;
    try {
      await createFloorPlan({
        name,
        projectId: Number(projectId),
        canvasWidth: 900,
        canvasHeight: 600,
      });
      setName("");
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this floor plan?")) return;
    try {
      await deleteFloorPlan(id);
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  if (loading) return <p>Loading…</p>;

  return (
    <div className="project-detail">
      <Link to="/" className="project-detail__back">
        ← All projects
      </Link>

      {project && (
        <>
          <h1>{project.name}</h1>
          {project.description && <p className="project-detail__desc">{project.description}</p>}
        </>
      )}

      {error && <div className="project-detail__error">{error}</div>}

      <form className="project-detail__form" onSubmit={handleCreate}>
        <input
          type="text"
          placeholder="New floor plan name (e.g. Ground Floor)"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <button type="submit">+ New Floor Plan</button>
      </form>

      {floorPlans.length === 0 ? (
        <p className="project-detail__empty">No floor plans yet.</p>
      ) : (
        <ul className="floorplan-list">
          {floorPlans.map((fp) => (
            <li key={fp.id} className="floorplan-list__item">
              <Link to={`/floorplans/${fp.id}`}>{fp.name}</Link>
              <span className="floorplan-list__meta">
                {fp.rooms?.length || 0} room{(fp.rooms?.length || 0) === 1 ? "" : "s"}
              </span>
              <button onClick={() => handleDelete(fp.id)}>Delete</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
