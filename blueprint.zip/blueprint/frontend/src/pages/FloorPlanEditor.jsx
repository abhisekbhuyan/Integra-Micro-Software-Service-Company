import React, { useEffect, useRef, useState, useCallback } from "react";
import { Link, useParams } from "react-router-dom";
import {
  getFloorPlan,
  createRoom,
  updateRoom,
  deleteRoom,
} from "../api/api";
import "./FloorPlanEditor.css";

const ROOM_TYPES = [
  { value: "BEDROOM", label: "Bedroom", color: "#93c5fd" },
  { value: "BATHROOM", label: "Bathroom", color: "#a7f3d0" },
  { value: "KITCHEN", label: "Kitchen", color: "#fde68a" },
  { value: "LIVING_ROOM", label: "Living Room", color: "#fca5a5" },
  { value: "HALLWAY", label: "Hallway", color: "#e5e7eb" },
  { value: "GENERIC", label: "Other", color: "#c4b5fd" },
];

const colorForType = (type) =>
  ROOM_TYPES.find((t) => t.value === type)?.color || "#93c5fd";

const MIN_SIZE = 20;

export default function FloorPlanEditor() {
  const { floorPlanId } = useParams();
  const [floorPlan, setFloorPlan] = useState(null);
  const [rooms, setRooms] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [mode, setMode] = useState("select"); // 'select' | 'draw'
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  const svgRef = useRef(null);
  const drag = useRef(null); // { type: 'move'|'resize'|'draw', roomId, startX, startY, orig }

  useEffect(() => {
    setLoading(true);
    getFloorPlan(floorPlanId)
      .then((fp) => {
        setFloorPlan(fp);
        setRooms(fp.rooms || []);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [floorPlanId]);

  const toCanvasCoords = useCallback((clientX, clientY) => {
    const rect = svgRef.current.getBoundingClientRect();
    return { x: clientX - rect.left, y: clientY - rect.top };
  }, []);

  const selectedRoom = rooms.find((r) => r.id === selectedId) || null;

  // ---- Drawing a brand-new room ----
  const handleCanvasMouseDown = (e) => {
    if (mode !== "draw") {
      setSelectedId(null);
      return;
    }
    const { x, y } = toCanvasCoords(e.clientX, e.clientY);
    drag.current = { type: "draw", startX: x, startY: y };
    setRooms((prev) => [
      ...prev,
      { id: "draft", label: "New Room", roomType: "GENERIC", x, y, width: 1, height: 1, color: colorForType("GENERIC") },
    ]);
  };

  // ---- Moving / resizing an existing room ----
  const startMove = (room) => (e) => {
    e.stopPropagation();
    if (mode !== "select") return;
    const { x, y } = toCanvasCoords(e.clientX, e.clientY);
    setSelectedId(room.id);
    drag.current = { type: "move", roomId: room.id, startX: x, startY: y, orig: { ...room } };
  };

  const startResize = (room) => (e) => {
    e.stopPropagation();
    const { x, y } = toCanvasCoords(e.clientX, e.clientY);
    setSelectedId(room.id);
    drag.current = { type: "resize", roomId: room.id, startX: x, startY: y, orig: { ...room } };
  };

  const handleMouseMove = (e) => {
    if (!drag.current) return;
    const { x, y } = toCanvasCoords(e.clientX, e.clientY);
    const d = drag.current;

    if (d.type === "draw") {
      const nx = Math.min(d.startX, x);
      const ny = Math.min(d.startY, y);
      const w = Math.abs(x - d.startX);
      const h = Math.abs(y - d.startY);
      setRooms((prev) => prev.map((r) => (r.id === "draft" ? { ...r, x: nx, y: ny, width: w, height: h } : r)));
    } else if (d.type === "move") {
      const dx = x - d.startX;
      const dy = y - d.startY;
      setRooms((prev) =>
        prev.map((r) => (r.id === d.roomId ? { ...r, x: d.orig.x + dx, y: d.orig.y + dy } : r))
      );
    } else if (d.type === "resize") {
      const dx = x - d.startX;
      const dy = y - d.startY;
      setRooms((prev) =>
        prev.map((r) =>
          r.id === d.roomId
            ? { ...r, width: Math.max(MIN_SIZE, d.orig.width + dx), height: Math.max(MIN_SIZE, d.orig.height + dy) }
            : r
        )
      );
    }
  };

  const handleMouseUp = async () => {
    const d = drag.current;
    drag.current = null;
    if (!d) return;

    if (d.type === "draw") {
      const draft = rooms.find((r) => r.id === "draft");
      setRooms((prev) => prev.filter((r) => r.id !== "draft"));
      if (draft && draft.width > MIN_SIZE && draft.height > MIN_SIZE) {
        try {
          const saved = await createRoom({
            label: draft.label,
            roomType: draft.roomType,
            x: draft.x,
            y: draft.y,
            width: draft.width,
            height: draft.height,
            rotation: 0,
            color: draft.color,
            floorPlanId: Number(floorPlanId),
          });
          setRooms((prev) => [...prev, saved]);
          setSelectedId(saved.id);
          setMode("select");
        } catch (err) {
          setError(err.message);
        }
      }
    } else if (d.type === "move" || d.type === "resize") {
      const room = rooms.find((r) => r.id === d.roomId);
      if (room) persistRoom(room);
    }
  };

  const persistRoom = async (room) => {
    try {
      const saved = await updateRoom(room.id, {
        label: room.label,
        roomType: room.roomType,
        x: room.x,
        y: room.y,
        width: room.width,
        height: room.height,
        rotation: room.rotation || 0,
        color: room.color,
        floorPlanId: Number(floorPlanId),
      });
      setRooms((prev) => prev.map((r) => (r.id === saved.id ? saved : r)));
    } catch (err) {
      setError(err.message);
    }
  };

  const handlePropertyChange = (field, value) => {
    if (!selectedRoom) return;
    setRooms((prev) =>
      prev.map((r) =>
        r.id === selectedRoom.id
          ? { ...r, [field]: value, ...(field === "roomType" ? { color: colorForType(value) } : {}) }
          : r
      )
    );
  };

  const handleSaveProperties = () => {
    if (selectedRoom) persistRoom(selectedRoom);
  };

  const handleDeleteRoom = async () => {
    if (!selectedRoom) return;
    if (!window.confirm(`Delete "${selectedRoom.label}"?`)) return;
    try {
      await deleteRoom(selectedRoom.id);
      setRooms((prev) => prev.filter((r) => r.id !== selectedRoom.id));
      setSelectedId(null);
    } catch (err) {
      setError(err.message);
    }
  };

  if (loading) return <p>Loading floor plan…</p>;

  return (
    <div className="editor">
      <Link to={floorPlan ? `/projects/${floorPlan.projectId}` : "/"} className="editor__back">
        ← Back to project
      </Link>

      <div className="editor__header">
        <h1>{floorPlan?.name}</h1>
        <div className="editor__toolbar">
          <button
            className={mode === "select" ? "active" : ""}
            onClick={() => setMode("select")}
          >
            Select / Move
          </button>
          <button
            className={mode === "draw" ? "active" : ""}
            onClick={() => setMode("draw")}
          >
            + Draw Room
          </button>
        </div>
      </div>

      {error && <div className="editor__error">{error}</div>}

      <div className="editor__body">
        <svg
          ref={svgRef}
          className={`editor__canvas ${mode === "draw" ? "editor__canvas--draw" : ""}`}
          width={floorPlan?.canvasWidth || 900}
          height={floorPlan?.canvasHeight || 600}
          onMouseDown={handleCanvasMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
        >
          <rect width="100%" height="100%" fill="#fbfbfd" stroke="#d1d5db" />
          {rooms.map((room) => (
            <g key={room.id}>
              <rect
                x={room.x}
                y={room.y}
                width={room.width}
                height={room.height}
                fill={room.color}
                fillOpacity={room.id === selectedId ? 0.9 : 0.65}
                stroke={room.id === selectedId ? "#1d4ed8" : "#4b5563"}
                strokeWidth={room.id === selectedId ? 2 : 1}
                onMouseDown={startMove(room)}
                style={{ cursor: mode === "select" ? "move" : "default" }}
              />
              {room.width > 40 && room.height > 20 && (
                <text
                  x={room.x + room.width / 2}
                  y={room.y + room.height / 2}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fontSize="13"
                  fill="#1f2430"
                  pointerEvents="none"
                >
                  {room.label}
                </text>
              )}
              {room.id === selectedId && mode === "select" && (
                <rect
                  x={room.x + room.width - 8}
                  y={room.y + room.height - 8}
                  width={12}
                  height={12}
                  fill="#1d4ed8"
                  style={{ cursor: "nwse-resize" }}
                  onMouseDown={startResize(room)}
                />
              )}
            </g>
          ))}
        </svg>

        <aside className="editor__panel">
          {selectedRoom ? (
            <>
              <h3>Room Properties</h3>
              <label>
                Label
                <input
                  type="text"
                  value={selectedRoom.label}
                  onChange={(e) => handlePropertyChange("label", e.target.value)}
                />
              </label>
              <label>
                Type
                <select
                  value={selectedRoom.roomType}
                  onChange={(e) => handlePropertyChange("roomType", e.target.value)}
                >
                  {ROOM_TYPES.map((t) => (
                    <option key={t.value} value={t.value}>
                      {t.label}
                    </option>
                  ))}
                </select>
              </label>
              <div className="editor__dimensions">
                <span>{Math.round(selectedRoom.width)} × {Math.round(selectedRoom.height)} units</span>
              </div>
              <div className="editor__panel-actions">
                <button className="primary" onClick={handleSaveProperties}>
                  Save
                </button>
                <button className="danger" onClick={handleDeleteRoom}>
                  Delete
                </button>
              </div>
            </>
          ) : (
            <p className="editor__panel-hint">
              {mode === "draw"
                ? "Click and drag on the canvas to draw a new room."
                : "Select a room to edit its properties, or switch to Draw Room to add one."}
            </p>
          )}
        </aside>
      </div>
    </div>
  );
}
